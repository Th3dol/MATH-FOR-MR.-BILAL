// Browser-storage implementation. The course's boilerplate.js was not provided.
const STORAGE_KEY = 'fatima_inventory';

function getProducts() {
  try {
    const value = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    return Array.isArray(value) ? value : [];
  } catch {
    return [];
  }
}

function saveProducts(products) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(products));
}

function loadProducts() {
  const products = getProducts();
  const table = document.getElementById('productTable');
  table.replaceChildren();

  products.forEach((product, index) => {
    const row = document.createElement('tr');
    [product.name, product.description, product.stock, product.price, product.category].forEach(value => {
      const cell = document.createElement('td');
      cell.textContent = value;
      row.appendChild(cell);
    });
    const actionCell = document.createElement('td');
    const deleteButton = document.createElement('button');
    deleteButton.type = 'button';
    deleteButton.className = 'btn btn-danger btn-sm';
    deleteButton.textContent = 'Delete';
    deleteButton.addEventListener('click', () => deleteProduct(index));
    actionCell.appendChild(deleteButton);
    row.appendChild(actionCell);
    table.appendChild(row);
  });
}

function deleteProduct(index) {
  const products = getProducts();
  products.splice(index, 1);
  saveProducts(products);
  loadProducts();
}

function sortProducts(order) {
  const products = getProducts();
  if (order === 'asc') {
    products.sort((a, b) => Number(a.price) - Number(b.price));
  } else if (order === 'desc') {
    products.sort((a, b) => Number(b.price) - Number(a.price));
  } else {
    return;
  }
  saveProducts(products);
  loadProducts();
}

document.getElementById('productForm').addEventListener('submit', function (event) {
  event.preventDefault();
  const product = {
    name: document.getElementById('productName').value.trim(),
    description: document.getElementById('description').value.trim(),
    stock: Number(document.getElementById('stock').value),
    price: Number(document.getElementById('price').value),
    category: document.getElementById('category').value
  };
  if (!product.name || !Number.isInteger(product.stock) || product.stock < 0 || !Number.isFinite(product.price) || product.price < 0) return;
  const products = getProducts();
  products.push(product);
  saveProducts(products);
  loadProducts();
  this.reset();
  bootstrap.Modal.getInstance(document.getElementById('productModal')).hide();
});

document.addEventListener('DOMContentLoaded', loadProducts);
