# ICT Code Collection

Collected from the ICT coursework discussed in ChatGPT on 27 October 2026.

## Folders
- `inventory-management/`: Fatima's Inventory Management System: display saved products, Add modal with validation, Delete, and price sorting (ascending/descending). Open `index.html` in a browser to run it.
- `task-master-notes/`: Task Master lesson objectives, HTML table classes and `queryData` starter function from screenshots.

## Important limitation
The original `boilerplate.js` database-operations file was not supplied. The inventory project consequently uses browser `localStorage`, **not** the course database. Browser-local data does not sync across browsers or devices. To meet the original course database requirement, replace `getProducts`/`saveProducts` and corresponding add/delete calls with the actual `boilerplate.js` APIs once supplied.

Sample product rows mentioned in the assignment (not preloaded): Rattles (10, 8, Wooden Toys), Jigsaw puzzle (25, 20, Puzzles), Teddy bear (18, 35, Plush toys), car (8, 80, Wooden Toys), Chess (4, 100, Wooden Toys).

## Related SQL quiz facts
```sql
DELETE FROM employee WHERE id = 1258;
SELECT * FROM employee ORDER BY salary ASC;
```
`WHERE` applies a condition. `ORDER BY` sorts query results. `ASC` means ascending (`ORDER BY salary` also defaults to ascending).

## Publishing on GitHub
Create a repository (for example `ict-coursework`) and upload the contents of this folder. Do not commit credentials, API keys or private database files.
