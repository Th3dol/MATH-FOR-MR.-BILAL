# Task Master — ICT Lesson Notes

These notes are from the user's provided slides; they are not a complete Task Master application.

## Learning objectives
- Retrieve stored data from database tables and display it dynamically.
- Validate required form fields and prevent duplicate records.
- Update task status and delete records through JavaScript/database queries.
- Sort tables in ascending or descending order.

## Table class names from the lesson
```html
<table class="table table-striped mt-2 dashBoardTable"></table>
<table class="table table-striped mt-2 completedTasksTable"></table>
```

## Starting function shown in the slide (indexPage.js)
```javascript
function queryData(statusValue) {
    let element, result;
}
```

Active tasks appear in the dashboard table; finished tasks appear in the completed tasks table. The slide did not provide the remaining database query implementation.
